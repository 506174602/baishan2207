<template>
  <div class="login">
    <div class="box">
      <h1>请登录账号</h1>
      <!--  model:表单数据对象
            rules:表单的验证规则
            ref:dom名字
       -->
      <el-form
        :model="ruleForm"
        :rules="rules"
        ref="ruleForm"
        label-width="100px"
        class="demo-ruleForm"
      >
        <!-- prop：表单验证的名字与rules名字一致 -->
        <el-form-item label="用户名" prop="tel">
          <!-- clearable可清空 -->
          <el-input
            v-model="ruleForm.tel"
            placeholder="请输入账号"
            clearable
          ></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="pwd">
          <!-- 加上show-password变成密码框 -->
          <el-input
            v-model="ruleForm.pwd"
            placeholder="请输入密码"
            show-password
          ></el-input>
        </el-form-item>
        <el-form-item>
          <!-- 传递的是绑定的对象ruleForm -->
          <el-button type="primary" @click="submitForm('ruleForm')"
            >提交</el-button
          >
          <el-button @click="resetForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      ruleForm: {
        tel: "18746526341",
        pwd: "",
      },
      // 表单验证
      rules: {
        tel: [
          // required：必填，message消息提示，trigger：触发的事件，数据发生变化的时候触发
          { required: true, message: "请输入账号", trigger: "change" },
          {
            //  pattern：写正则表达式
            pattern: /0?(13|14|15|18)[0-9]{9}/,
            message: "手机号输入不正确",
            trigger: "change",
          },
        ],
        pwd: [
          // required：必填，message消息提示，trigger：触发的事件，鼠标离开焦点的时候触发
          { required: true, message: "请输入密码", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    // 传递ruleForm，接收formName
    submitForm(formName) {
      // validate：对整个表单进行校验的方法，参数为一个回调函数。
      // 第二种函数不接受参数，this.$refs.ruleForm.validate((valid) => {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          console.log(this.ruleForm);
          //   定义变量，将input里面的值给要传递的参数
          let data = {
            telnumber: this.ruleForm.tel,
            password: this.ruleForm.pwd,
          };
          this.$axios
            .post(
              //  this.$qs.stringify()方法将 {"telnumber":"18746526341","password":"123456"}转成字符串形式
              // this.$qs.stringify() 将对象序列化为URL的形式，以&拼接。
              // this.$qs.parse() 将url解析成对象的形式
              "test/login",
              this.$qs.stringify(data),
              // {
              //   telnumber: this.ruleForm.tel,
              //   password: this.ruleForm.pwd,
              // },
              {
                headers: {
                  "Content-type": "application/x-www-form-urlencoded",
                },
              }
            )
            .then((res) => {
              console.log(res);
              //   判断状态，200登陆成功
              if (res.data.code == 200) {
                this.$message({
                  message: res.data.message,
                  type: "success",
                });
                //   用户登录成功之后,会返回一个token/session,经过md5加密后的一串字符串,判断用户身份
                //   增删改产所有的接口都需要携带这个参数,每次请求接口都会传这个字符串,一般情况都封装起来,在请求头传递
                sessionStorage.setItem(
                  "token",
                  "b0fc6da640a5c333707e119c58318379"
                );
                sessionStorage.setItem("tel", res.data.user.telnumber);
                sessionStorage.setItem("name", "李先亮");

                // 跳转路由
                this.$router.push({
                  path: "/index/fuzi",
                });
              } else {
                this.$message.error(res.data.message);
              }
            });
        } else {
          return false;
        }
      });
    },
    resetForm(formName) {
      // resetFields()清空所有表单内容的方法
      this.$refs[formName].resetFields();
    },
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
.login::v-deep {
  .box {
    position: absolute;
    left: 50%;
    bottom: 0;
    top: 50%;
    right: 0;
    width: 350px;
    height: 300px;
    margin-top: -150px;
    margin-left: -175px;
    box-shadow: 0 0 25px #999;
    padding: 0 20px;
    h1 {
      font-size: 20px;
    }
    .el-form-item__label {
      text-align: center;
    }
  }
}
</style>
