<template>
  <div>
    <!-- 3 使用组件 -->
    <qheader></qheader>
    <p>{{msg}}</p>
    <qcenter></qcenter>
  </div>
</template>
<script>
// 1 引入组件
import qcenter from "@/components/qcenter.vue";
import qheader from "@/components/qheader.vue";
// 2 注册组件
export default {
  components: {
    qcenter,
    qheader,
  },
  data() {
    return {
      msg:""
    };
  },
  //  监听路由的变化,只要路由发生变化就打印数据
  watch: {
    $route:{
				handler(newVal){
					// console.log(newVal,"监听数据obj发生了变化")
          this.msg=newVal.meta.title
				},
				// 深度监听
				deep:true,
				// 初始化监听
				immediate:true,
			},
  },
  // 2、路由更新前的守卫，跟watch实现功能一样
  // beforeRouteUpdate(to,from,next){
  //   // 只要路由发生变化的时候，就将路由里面配置的元信息中的title，赋值给msg渲染出来
  //   this.msg=to.meta.title
  //   console.log(to,"想去哪个路由")
  //   console.log(from,"我来自哪个路由")
  //   next()
  // }
};
</script>
<!--
SCSS是一种CSS预处理语言, 它是SASS的升级版, 编译后形成正常的css文件，为css增加一些编程特性，无需考虑浏览器的兼容性（完全兼容css3），
让css更加简洁、适应性更强，可读性更佳，更易于代码的维护等诸多好处。CSS预处理语言有SCSS (SASS) 和LESS、POSTCSS

安装scss依赖： npm  install sass-loader --save

使用scss时, 在所在的style样式标签上添加lang=”scss”即可应用对应的语法，否则报错.如：
< style lang = "scss" >
$color: pink ;
body{
  div { color : $color;}
}
</ style >
其中 $color: pink, 是声明变量的语法：$+变量名+：+变量值, 且该$color为全局变量，因为不在body大花括号内; 而局部变量是声明在元素内的;
变量嵌套引用：即字符串插值，需要使用 #{} 来进行包裹， 如：
$right: right;
你想写一个  border-right: 2px solid pink; 用变量表示则为:
border-#{$left}: 2px solid pink;


注释分为三种：
1: /* */    css中显示，
2: //       css中不显示，
3: /*重要注释!*/    压缩不会被删掉。

@import 命令, 可以实现导入外部sass、scss、css文件

嵌套: 在嵌套时候可以使用 & 来引用父元素, 如：
.container {
   & > span { // 即CSS的 .container>span {} 效果
      color : purple ;
   }
}
混入 @mixin
继承 @extend：继承 其他的.class 样式，需要 使用 @extend, 如：
.container {
   color : pink ;
   border : 2px dashed green ;
}
.myDemo {
   @extend .container; //这里会继承.container类的所有样式
   font-size : 12px ;
}

-->
<style lang="scss" scoped>
p{
  text-align: left;
  position: absolute;
  left: 280px;
  top: 60px;
  z-index: 99;
}
</style>
