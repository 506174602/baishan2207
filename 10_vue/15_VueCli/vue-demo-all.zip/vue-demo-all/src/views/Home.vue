<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <!-- 3 使用组件 -->
    <!-- <HelloWorld /> -->
    <hello></hello>
    <fabc></fabc>
  </div>
</template>

<script>
// 1 引入组件  @是相对路径,相对于src
import HelloWorld from '@/components/HelloWorld.vue'
// import fabc from '@/components/fuzi/index.vue'
import fabc from '../components/fuzi/index.vue'
export default {
  name: 'Home',
  // 2 注册局部组件
  components: {
    // value:key

    // es6简写
    // HelloWorld:HelloWorld,
    // HelloWorld,

    // 标签名:引入的组件
    hello:HelloWorld,
    fabc,
  }
}
</script>
