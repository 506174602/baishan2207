<template>
  <div class="about">
    <h1>我是about组件中的h1标签

      <span>我是span</span>
    </h1>
  </div>
</template>

<style lang="css" scoped>
/*
  css样式会使整个项目都生效,加上scoped只在当前组件中生效,
  lang代表的是语言,样式表用的哪一种语言,可以是css/scss/less/sass.
  在使用任何组件之前一定先npm一下,即安装一下项目依赖
  为什么scss没有安装就能用?因为搭建项目的时候已经安装了,已经npm install
  如果使用scss报错说明项目中使用了scss但是依赖没有安装
 */
/* h1{
  color: red;
} */
</style>

<style lang="scss" scoped>
// 引入外部样式
@import "./style.scss"
/*
    Scoped CSS规范是Web组件产生不污染其他组件，也不被其他组件污染的CSS规范。
    scoped 样式只在当前组件中生效，不加scoped会使样式在所有组件中都生效，产生样式冲突。

    scoped很重要，项目中必须用，
    当然项目中也可以不加scoped也可以避免样式冲突，就是起类名不一样。
    但是一个项目有上百个组件，并且是多人协作开发，难免会产生不同人起的类名一样。这样就会导致类名冲突，布局及样式乱。
    
    /deep/ vue组件中，在style设置为scoped的时候，里面在写样式对子组件有时候是不生效的，
    如果想让某些样式对所以子组件都生效，可以使用 /deep/ 深度选择器。
    儿子不生效给老子加深度监听，最好是给最外层的祖宗加，这样就能深度监听自己的子孙
    
    用法：/deep/或者::v-deep
    .Home /deep/
    .Home::v-deep

    // 只要在about这个div下,所有的后代都能够深度监听到,不会出现样式不生效
    .about ::v-deep{
      color:red
    }
*/ 

</style>

// css模板
// <style lang="scss" scoped>
// css层级过深会导致找不到,会导致样式不生效
// .box ::v-deep{
  
// }
// </style>

/* 
  css、sass、scss、less区别？
    css：层叠样式表
    Sass：是一种动态样式语言，Sass语法属于缩排语法，比css比多出好些功能(如变量、嵌套、运算,混入(Mixin)、继承、颜色处理，函数等)，更容易阅读。
    Scss：Scss是sass 引入的新语法，其语法完全兼容css3，并且继承了sass
    Less：是一门CSS预处理语言，它扩展了CSS语言，增加了变量，Mixin，函数等特性，使CSS更易维护和扩展。

  1、Less与Sass/scss处理机制不同：
  Less是通过客户端处理的，Sass是通过服务端处理，相比较之下Less解析会比Sass/scss慢一点。

  2、变量符不一同
  Less是@，而Sass是$，而且变量的作用域也不一样。
  Sass没有局部变量，满足就近原则。Less中{}内定义的变量为局部变量。

  3、Less没有输出设置，Sass提供4中输出选项，默认为nested
  nested：嵌套缩进的css代码
  expanded：展开的多行css代码
  compact：简洁格式的css代码
  compressed：压缩后的css代码

  Sass支持条件语句，可以使用if else，for循环等，而Less不支持。

  scss是Sass升级版本。综上相比较而言，scss是最好的选择。

详情：
  https://blog.csdn.net/weixin_43735746/article/details/101775009?utm_medium=distribute.pc_relevant.none-task-blog-2~default~OPENSEARCH~default-1.no_search_link&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2~default~OPENSEARCH~default-1.no_search_link
  https://blog.csdn.net/Menqq/article/details/112689377
*/
