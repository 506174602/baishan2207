<template>
  <div id="app">
    <!-- 
      router-link相当于a标签
      tag="要改变的标签名"
      to="想跳转的路径地址"
     -->
    <!-- <div id="nav">
      <router-link to="/" tag="div">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div> -->
    <!-- 所有的页面都称之为一个组件,页面时若干个组件拼接而成的,因为vue项目是单页面应用, 只是在跳转路由的时候重新渲染一个需要显示的组件而已-->
    <!-- 显示的组件 -->
    <router-view/>
  </div>
</template>


<style lang="scss">
html,body{
  padding: 0;
  margin: 0;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}

</style>
<style>
/* 引入线上图标库 */
@import './assets/icon/iconfont.css';
/* 引入字体文件 */
@font-face {
  font-family: Digital;
  src: url(~@/assets/DS-DIGIB.TTF);
}

/* 全局css滚动条 */
::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 3px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 1px;
}
::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 3px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: #535353;
}
::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  border-radius: 3px;
  background: #ededed;
}
</style>
