import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  // 1、存储公共状态或者数据
  state: {
    count:1
  },
  // 2、用来处理异步数据
  actions: {
    // 参数1：vuex这个对象，这个对象中有commit方法，参数2：传过来的值5
    handleChange({commit},params){
      console.log(params,commit) 
      // commit有两个参数。参数1：mutations中的函数方法，参数2：是传过来的值5
      commit("handleMutation",params)
    },
  },
  // 3、用来处理同步数据修改，修改的是state中的数据
  mutations: {
    // 参数1：定义的初始数据state，参数2:传过来的值5
    handleMutation(state,params){
      console.log(state,params) // {count:1} 5
      // 每次+5
      state.count+=params
    }
  },
  // 4、计算相当于计算属性
  getters:{
    // 函数名是state里面的变量，不能更改
    count(state){
      return state.count+10
    }
  },
  // 5、导入子模块
  modules: {
  }
})


// 1 非父子传参，给vue加一个原型observer
Vue.prototype.$observer=new Vue()

/*
  非父子传参：
    1、给vue加一个原型observer
      Vue.prototype.$observer=new Vue()
    2、发送
      语法：this.$store里面起的vue原型的名字.$emit("自定义的方法名字"，传递的参数)

      this.$observer.$emit("自定义的方法名字"，传递的参数)
    3、接收
      语法：this.$store里面起的vue原型的名字.$on(自定义的方法名字，(接收的参数)=>{})

      this.$observer.$on('自定义的方法名字',(params)=>{
        console.log(params,"非父子接收")
      })
*/ 
/*
    知道vuex吗？了解吗？vuex有几种状态？
    vuex是一种最好的非父子传参的方式，vuex就是状态存储。
    有5种状态：
      1、存储公共状态或者数据state
      2、用来处理异步数据actions
      3、用来处理同步数据修改，mutations
      4、计算相当于计算属性，getters
      5、导入子模块，modules


      工作流程：
        当组件想要修改state里面的数据时，需要调用this.$store.dispatch来触发action里面的方法，
        在这个方法中返回了两个参数，一个是commit方法，一个是传递过来的值，然后在函数内部调用commit方法，commit方法触发mutations里面的函数
        mutations这个函数专门修改state里面的数据，当mutations里面的函数触发后state数据就会被修改。
        
*/ 