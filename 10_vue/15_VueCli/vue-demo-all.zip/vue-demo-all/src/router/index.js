// 引入vue
import Vue from 'vue'
import VueRouter from 'vue-router'
// 1 引入组件
// import Home from '../views/Home.vue'

// 3 创建router实例
Vue.use(VueRouter)

// 2 定义路由路径，映射每一个组件
const routes = [
  {	
    // 默认显示第一个login，登陆页面
    path:'/',
    // 重定向，设置之后默认打开的是第一个组件
    redirect:'/login'
  },
  // 登录
  {
    path: '/login',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '../views/login.vue')
  },
  { 
    // path是跳转的路径，跳转用的。
    path: '/index',
    // 名字，parmas传值用的
    name: 'index',
    // 组件的位置
    component: () => import(/* webpackChunkName: "Home" */ '@/views/index.vue'),
    // 后代 路由嵌套
    children:[
      /*
        /index/fuzi简写fuzi
      */
        { 
          path: 'fuzi',
          name: 'fuzi',
          component: () => import(/* webpackChunkName: "fuzi" */ '@/components/fuzi/index.vue'),
          // 元信息
          meta:{
            title:"组件传参>父子传参"
          }
        },
        { 
          path: 'zifu',
          name: 'zifu',
          component: () => import(/* webpackChunkName: "zifu" */ '@/components/zifu/index.vue'),
          meta:{
            title:"组件传参>子父传参"
          }
        },
        { 
          path: 'params',
          name: 'params',
          component: () => import(/* webpackChunkName: "params" */ '@/components/routerPage/params.vue'),
          meta:{
            title:"组件传参>子父传参"
          }
        },
        { 
          path: 'query',
          name: 'query',
          component: () => import(/* webpackChunkName: "query" */ '@/components/routerPage/query.vue'),
          meta:{
            title:"组件传参>子父传参"
          }
        },
        { 
          path: 'details',
          name: 'xq',
          component: () => import(/* webpackChunkName: "details" */ '@/components/routerPage/details.vue')
        },
        { 
          path: 'echa',
          name: 'echa',
          component: () => import(/* webpackChunkName: "echa" */ '@/components/echa/index.vue'),
          meta:{
            title:"echars"
          }
        },
        { 
          path: 'axios',
          name: 'axios',
          component: () => import(/* webpackChunkName: "axios" */ '@/components/axios/index.vue'),
          meta:{
            title:"axios"
          }
        },
        { 
          path: 'vuex',
          name: 'vuex',
          component: () => import(/* webpackChunkName: "vuex" */ '@/components/vuex/index.vue'),
          meta:{
            title:"vuex"
          }
        },
        { 
          path: 'add',
          name: 'add',
          component: () => import(/* webpackChunkName: "add" */ '@/components/additem/index.vue'),
          meta:{
            title:"海南残联>创建团队"
          }
        },
        { 
          path: 'list',
          name: 'list',
          component: () => import(/* webpackChunkName: "tableList" */ '@/components/tableList/index.vue'),
          meta:{
            title:"海南残联>团队看板"
          }
        },
        { 
          // path是跳转的路径
          path: 'kb',
          name: 'kb',
          // 组件的位置
          component: () => import(/* webpackChunkName: "tableList" */ '@/components/houdong/index.vue'),
          meta:{
            title:"海南残联>活动看板"
          }
        },
    ]
  },
  { 
    // 路径
    path: '/home',
    name: 'Home',
    // 组件地址映射
    // component: Home
    component: () => import(/* webpackChunkName: "Home" */ '@/views/Home.vue')
  },
  {
    path: '/about',
    name: 'About',
    // es6
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  }
]

/*
  vue-router有hash和history两者模式
  vue的路由默认是hash模式，即地址栏 URL 中的 # 符号。（vue部署时使用这个模式解决刷新404的问题，但是一般用history模式，配合后端修改路由刷新）
  *如果使用history模式必须得到后端的支持
  
*/ 
const router = new VueRouter({
  mode:"history",
  routes
})

// 全局守卫
router.beforeEach((to,from,next)=>{
  // 如果想去的路由是登录页面，就放行
  if(to.path=='/login'){
    return next();
  }
  // 将缓存里面的数据取出来
  const token=sessionStorage.getItem("token")
  // 如果缓存里面没有数据,跳转到登录页面
  if(!token){
    alert("请登陆后访问")
    return next("/login");
  }
  next()
})

export default router
