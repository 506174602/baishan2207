// template插槽，放组件内容的，里面只能有一个元素div，大盒子
<template>
  <div class="box">
      <!-- 
          to路径
          tag改变标签名
          2、query传值
          :to="{path:'组件路径',query:{对象的形式，将需要传给下一个页面的参数传递过去}}}"
       -->
      <!-- <router-link :to="{path:'details',query:{id:item.id,name:item.name}}" class="box-list" v-for="(item,index) in list" :key="index">
          <div class="list-name">
            {{item.name}}
          </div>
          <div class="list-img">
              <img :src="item.ImgUrl" alt="">
          </div>
      </router-link> -->

      <!-- 事件方法 -->
      <div class="box-list" v-for="(item,index) in list" :key="index" @click="handlePush(item)">
          <div class="list-name">
            {{item.name}}
          </div>
          <div class="list-img">
              <img :src="item.ImgUrl" alt="">
          </div>
      </div>
  </div>
</template>
<script>
export default {
  // 定义变量的地方
  data() {
    return {
      list: [
        {
          id: 1001,
          name: "似水流年",
          ImgUrl:
            "https://ww3.sinaimg.cn/mw690/d127f8c9tw1eqx1im1nedj207h04zwel.jpg",
        },
        {
          id: 1002,
          name: "三生三世",
          ImgUrl:
            "https://ww3.sinaimg.cn/mw690/d127f8c9jw1eqm9ykd2r6j209q05gt8r.jpg",
        },
        {
          id: 1003,
          name: "只如初见",
          ImgUrl:
            "https://ww1.sinaimg.cn/mw690/d127f8c9jw1f68qt3jdhkj20m80cijsg.jpg",
        },
      ],
    };
  },
  // 存放函数的地方
  methods: {
    handlePush(row){
      // query传值。事件函数
      this.$router.push({
        // 路径
        path:"details",
        query:{
          id:row.id,
          name:row.name,
        }
      })
      
      // parmas传值。事件函数
      // this.$router.push({
      //   // 名字
      //   name:"xq",
      //   parmas:{
      //     id:row.id,
      //     name:row.name,
      //   }
      // })
    }
  },
  // 声明周期，dom加载完成之后
  mounted() {},
};
</script>

<style lang="scss" scoped>
.box::v-deep{
    .box-list{
        padding: 10px;
        width: 100px;
        text-align: center;
        display: inline-block;
        text-decoration: none;
        .list-name{
            height: 30px;
            text-align: center;
            line-height: 30px;
            color: #000;
        }
        .list-img{
            width: 100px;
            height: 60px;
            vertical-align: middle;
            img{
                width: 100%;
                height: 55px;
            }
        }
    }
    
}
</style>