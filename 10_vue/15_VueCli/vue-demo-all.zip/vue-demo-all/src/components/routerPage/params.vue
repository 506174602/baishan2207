// template插槽，放组件内容的，里面只能有一个元素div，大盒子
<template>
  <div class="box">
    <!-- 
          to路径
          tag改变标签名

          1、params传值
          通过路由配置的name跳转的
            name:路由配置里面的name
            params:{
                idd:item.id,
                names:item.name,
            }
          :to="{name:'路由配置的名字',params:{对象的形式，将需要传给下一个页面的参数传递过去}}"
       -->
       
    <!-- <a href="#/index/details" @click="forward">第一种跳转</a> -->
    <a href="javascript:;" @click="forward">前进</a>

    <!-- <router-link :to="{name:'xq',params:{id:item.id,name:item.name}}" class="box-list" v-for="(item,index) in list" :key="index">
          <div class="list-name">
            {{item.name}}
          </div>
          <div class="list-img">
              <img :src="item.ImgUrl" alt="">
          </div>
      </router-link> -->

    <div
      class="box-list"
      v-for="(item, index) in list"
      :key="index"
      @click="handlePush(item)"
    >
      <div class="list-name">
        {{ item.name }}
      </div>
      <div class="list-img">
        <img :src="item.ImgUrl" alt="" />
      </div>
    </div>

    <!-- 
          跳转方式：
            1  <a href="#/index/details">第一种跳转</a>
            2  <router-link :to="{name:'xq',params:{id:item.id,name:item.name}}"></router-link>
            3  事件方法：this.$router.push({})
       -->
  </div>
</template>
<script>
export default {
  // 定义变量的地方
  data() {
    return {
      list: [
        {
          id: 1001,
          name: "似水流年",
          ImgUrl:
            "https://ww3.sinaimg.cn/mw690/d127f8c9tw1eqx1im1nedj207h04zwel.jpg",
        },
        {
          id: 1002,
          name: "三生三世",
          ImgUrl:
            "https://ww3.sinaimg.cn/mw690/d127f8c9jw1eqm9ykd2r6j209q05gt8r.jpg",
        },
        {
          id: 1003,
          name: "只如初见",
          ImgUrl:
            "https://ww1.sinaimg.cn/mw690/d127f8c9jw1f68qt3jdhkj20m80cijsg.jpg",
        },
      ],
    };
  },
  // 存放函数的地方
  methods: {
    handlePush(row) {
      console.log(row, "接收的每条数据");
      //   事件方法，必需记住
      this.$router.push({
        name: "xq",
        params: {
          id: row.id,
          name: row.name,
        },
      });
    },
    forward(){
        // 前进
        this.$router.forward()
        /*        
            this.$router.back()  返回
            this.$router.go(-1) this.$router.go(-1) 后退返回
            
            this.$router.forward() 前进
            this.$router.go(1)  前进
            this.$router.replace() 替换
        
        */ 
    }
  },
  // 声明周期，dom加载完成之后
  mounted() {},
};
</script>

<style lang="scss" scoped>
.box::v-deep {
  .box-list {
    padding: 10px;
    width: 100px;
    text-align: center;
    display: inline-block;
    text-decoration: none;
    .list-name {
      height: 30px;
      text-align: center;
      line-height: 30px;
      color: #000;
    }
    .list-img {
      width: 100px;
      height: 60px;
      vertical-align: middle;
      img {
        width: 100%;
        height: 55px;
      }
    }
  }
}
</style>