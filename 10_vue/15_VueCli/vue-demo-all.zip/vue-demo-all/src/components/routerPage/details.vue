// template插槽，放组件内容的，里面只能有一个元素div，大盒子
<template>
  <div class="box">
    <p>params接收id：{{ obj.id }}</p>
    <p>params接收name：{{ obj.name }}</p>

    <p>query接收id：{{ qObj.id }}</p>
    <p>query接收name：{{ qObj.name }}</p>

    <button @click="handlleClick">返回</button>
  </div>
</template>
<script>
export default {
  // 定义变量的地方
  data() {
    return {
      obj: {
        id: "",
        name: "",
      },
      qObj: {
        id: "",
        name: "",
      },
    };
  },
  // 存放函数的地方
  methods: {
    // 1、通过params接收
    handleSeach() {
      console.log(this.$route.params, "我是通过params接收");
      this.obj.name = this.$route.params.name;
      this.obj.id = this.$route.params.id;
    },
    // 2、通过query接收
    handleQuery() {
      console.log(this.$route.query, "我是通过query接收");
      this.qObj.name = this.$route.query.name;
      this.qObj.id = this.$route.query.id;
    },
    handlleClick() {
      this.$router.go(-1);
    },
  },
  // 声明周期，dom加载完成之后
  mounted() {
    this.handleSeach();
    this.handleQuery();
  },
  // 1、进入路由前验证

  // 想去那个路由，从哪来路由过来的，跳转到哪(开始执行跳转)
  beforeRouteEnter(to, from, next) {
    // 判断缓存有没有值，有值进详情页
    alert("进入路有前验证");
    next();

    // 举例
    // if (sessionStorage.getItem("name")) {
    //   next();
    // } else {
    //   // 没有值进跳转fuzi组件
    //   next((vm) => {
    //     // console.log(vm);
    //     // 在当前路由生命周期中是访问不到this指向
    //     // 所以用next的回调就是this,所以vm就是this
    //     vm.$router.push({
    //       path: "/index/fuzi",
    //     });
    //   });
    // }
    console.log(to.path, "想去那个路由");
    console.log(from.path, "从哪来路由过来的");
  },

  // 3、离开路由的时候验证
  beforeRouteLeave(to,from,next){
    alert("我要离开这个页面了，是否保存？")
    next()
  }
};
/*

路由守卫：路由钩子函数，路由跳转前的验证

全局守卫:
  在路由配置中使用。用于用户的登陆验证
  beforeEach()
  
局部守卫

  (to,from,next)=>（想去那个路由，从哪来路由过来的，跳转到哪）

  1、beforeRouteEnter(to,from,next)：进入路由前的守卫————用于用户是否登录验证、异地登陆、VIP即将到期的时间判断
  *注意：在当前路由生命周期中是访问不到this指向，因为只有通过了当前路由守卫才能执行beforeCreate等生命周期。
  *如果希望在当前路由钩子函数中访问当前this指向，如何解决？
      利用next()函数的回调中可以获得
      next((vm)=>{
        console.log(vm)
      })
  
  2、beforeRouteUpdate：路由更新的守卫
  
	3、beforeRouteLeave(to,from,next)：路由离开时的守卫————用于未支付、答题系统、页面信息是否保存

*/
</script>

<style lang="scss" scoped>
</style>