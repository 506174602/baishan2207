<template>
  <div class="hello">
    <h1>我是hello组件中的h1标签</h1>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  }
}
</script>