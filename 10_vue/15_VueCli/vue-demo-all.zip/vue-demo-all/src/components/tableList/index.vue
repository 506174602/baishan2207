<template>
  <div>
    <!-- 绑定变量tableData -->
    <!-- v-loading加载动画 -->
    <el-table
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(0, 0, 0, 0.8)"
      :data="tableData"
      style="width: 100%"
      height="500px"
    >
      <!-- prop是后端请求过来的对应的字段名 -->
      <el-table-column label="序号" type="index" width="50"></el-table-column>
      <el-table-column prop="teamname" label="团队名称"> </el-table-column>
      <el-table-column prop="mailbox" label="团队邮箱"> </el-table-column>
      <el-table-column prop="teamdescribe" label="团队描述"> </el-table-column>
      <el-table-column prop="createdAt" label="创建时间"> </el-table-column>
      <el-table-column fixed="right" label="操作" width="200">
        <!-- template插槽, slot-scope="scope" 返回整个表格的属性，scope.row当前行的数据-->
        <template slot-scope="scope">
          <!-- plain按钮镂空 -->
          <el-button
            type="danger"
            size="small"
            plain
            @click="handleDel(scope.row)"
          >
            删除
          </el-button>
          <el-button
            type="primary"
            size="small"
            plain
            @click="handleEidt(scope.row)"
          >
            编辑
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [],
      loading: true,
    };
  },
  methods: {
    //   请求查询表格列表
    handleSeach() {
      this.axios.get("test/getTeamAll").then((res) => {
        console.log(res);
        // 结束加载动画
        this.loading = false;
        // 将后端请求的数据给变量
        this.tableData = res.data;
      });
    },
    // 删除
    handleDel(row) {
      console.log(row.id);

      this.$confirm(`此操作将永久删除${row.teamname}数据, 是否继续?`, "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // let id={
          //     id:row.id
          // }
          this.axios
            .post("test/deleteById", this.$qs.stringify({ id: row.id }))
            .then((res) => {
              console.log(res);
              if (res.data.code == 200) {
                this.$message({
                  type: "success",
                  message: "删除成功!",
                });
                // 重新调一下查询接口，渲染数据,
                this.handleSeach();
              }
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    // 编辑跳转页面传值
    handleEidt(row) {
        console.log(row)
        // 路由跳转到创建团队这个组件中，并把当前行数据传给创建团队这个组件中
        this.$router.push({
          path:"/index/add",
          query:{
            id:row.id,
            teamname:row.teamname,
            mailbox:row.mailbox,
            teamdescribe:row.teamdescribe
          }
        })
    },
  },
  created() {
    this.handleSeach();
  },
  mounted() {},
};
</script>
