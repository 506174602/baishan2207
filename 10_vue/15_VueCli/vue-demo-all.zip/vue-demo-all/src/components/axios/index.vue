<template>
  <div>
    <input type="text" v-model="city" />
    <button @click="handleGet">点击</button>
    <ul>
      <li v-for="(item, index) in list" :key="index">天气：{{ item.text }}--温度：{{item.temp}}℃</li>
    </ul>
  </div>
</template>
<script>
export default {
  data() {
    return {
      city: "青岛",
      list: [],
    };
  },
  methods: {
    /*
      *基本使用:

      this.axios({
        method: "请求的方式",
        url: "请求地址",
        params: {
          // 请求携带的参数
          // location: "青岛",
        },
        headers:"请求头",
      }).then((response) => {
          // 请求成功回调的函数
          console.log(response.data);
        })
        .catch(err => {
          // 请求失败的回调
          console.log(err);
        });

      1、get请求
      this.axios.get(url, {
          params: {
            get请求携带的参数
          }
        })
        .then(response => {
          // 请求成功回调的函数
          console.log(response.data);
        }).catch((err)=>{
        // 请求失败的回调
        console.log(err)
      })

      // 注意：get请求的时候参数要放在params中

      2、post请求
      this.axios.post(url, {
          post请求的时候传递的参数
        }).then(response => {
          // 请求成功回调的函数
          console.log(response.data);
        }).catch((err)=>{
        // 请求失败的回调
        console.log(err)
      })
 
    */
    handleGet() {
      // 1、基本用法
      //   this.axios({
      //     method: "get",
      //     url: "https://geoapi.qweather.com/v2/city/lookup",
      //     params: {
      //       location: this.city,
      //       key: "b118703e25a54b42ab7dade1256dc090",
      //     },
      //   })
      //     .then((response) => {
      //       // 请求成功回调的函数
      //       console.log(response.data);
      //     })
      //     .catch((err) => {
      //       // 请求失败的回调
      //       console.log(err);
      //     });

      //   第二种通过原型+基本用法
      // 因为我在main.js中把axios给了原型所以，this.axios或this.$axios都能用
      // 一般情况下在公司this.axios都是经过封装的，所以this.axios不起作用或者报错或者报跨域
      // 我不想用封装的我就想用原生的写？main.js中把axios给原型，通过原型去使用

      // this.$axios({
      //     method: "post",
      //     url: "https://www.iimake.com/mains/fast/findAllBaseShuffling",
      //     params: {
      //       shufflingNumber:3
      //     },
      //     // 请求头
      //     headers:{
      //         "Content-type":"application/x-www-form-urlencoded"
      //     }

      //   })
      //     .then((response) => {
      //       // 请求成功回调的函数
      //       console.log(response.data);
      //     })
      //     .catch((err) => {
      //       // 请求失败的回调
      //       console.log(err);
      //     });

      // 第三种方法
      //   this.axios
      //     .post("https://www.iimake.com/mains/fast/findAllBaseShuffling", {
      //       shufflingNumber: 3,
      //     })
      //     .then(
      //       (res) => {
      //         console.log(res.data.dataList);
      //       },
      //       (err) => {
      //         console.log(err);
      //       }
      //     );

      this.axios
        .get("https://geoapi.qweather.com/v2/city/lookup", {
          params: {
            location: this.city,
            key: "b118703e25a54b42ab7dade1256dc090",
          },
        })
        .then(
          (res) => {
            // console.log(res.data.location[0].id)
            // 把结果返回到下一个then函数里面
            return res.data.location[0].id;
          },
          (err) => {
            console.log(err);
          }
        )
        .then((id) => {
          console.log(id, "我是上一个then函数的返回结果");
          this.axios
            .get("https://devapi.qweather.com/v7/weather/24h", {
              params: {
                location: id,
                key: "b118703e25a54b42ab7dade1256dc090",
              },
            })
            .then((res) => {
              console.log(res, "天气");
              this.list = res.data.hourly;
            });
        });
    },
  },
  mounted() {
    this.handleGet();
  },
};
</script>
<style lang="scss" scoped>
ul {
  display: flex;
  flex-wrap: wrap;
}
ul li {
  list-style: none;
  width: 100px;
  padding: 10px 0;
  background-color: #ccc;
  color: #fff;
  margin-right: 10px;
  margin-bottom: 10px;
  text-align: center;
}
img {
  width: 50px;
}
</style>
