<template>
  <div>
    <el-header>
      <div @click="handleMlQ">非父子传参</div>
      <div>
        <el-dropdown>
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <a href="javascript:;" @click="handleOut">退出</a>
          </el-dropdown-menu>
        </el-dropdown>
        <span>{{ userName }}</span>
      </div>
    </el-header>
  </div>
</template>
<script>
export default {
  data() {
    return {
      // 取出缓存里面的名字
      userName: sessionStorage.getItem("name"),
    };
  },
  watch: {},
  methods: {
    handleOut() {
      this.$confirm("是否退出登录?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          // 清除缓存
          sessionStorage.removeItem("token")
          sessionStorage.removeItem("name")
          sessionStorage.removeItem("tel")
          // 跳转登陆页面
          this.$router.push({
            path:"/"
          })
          this.$message({
            type: "success",
            message: "退出成功!",
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消",
          });
        });
    },
    // 2 原型非父子传参发送
    handleMlQ() {
      console.log("我是XXX");
      //  this.$store里面起的vue原型的名字.$emit("自定义的方法名字"，传递的参数)
      this.$observer.$emit("handleLxl", "我是李先亮");
      // this.$observer.$emit("handleLxl",this.msg)
    },
  },
};
</script>
<style lang="scss" scoped>
.el-header::v-deep {
  background-color: #22262e;
  text-align: right;
  font-size: 12px;
  line-height: 60px;
  color: #fff;
  text-align: right;
  font-size: 12px;
  display: flex;
  justify-content: space-between;
  .el-dropdown {
    color: #fff;
  }
}
</style>
