<template>
    <div class="zifu">
        <h1>{{msg}}</h1>
        <!-- 3 使用 -->
        <!-- 4 给子组件绑定一个自定义方法，值为接收参数的函数， 注意这个函数不允许加(),否则接收不到 -->
        <!-- @自定义方法名="接收的函数，不允许加（）" -->
        <One @handleYuanye="handleData"></One>
        <p>
            我是从儿子那接收过来的数据：{{zifu}}
        </p>
    </div>
</template>
<script>
// 1 导入子组件
import One from "./zOne.vue"
// 导出
export default{
    // 标识
    name:"zOne",
    // 定义变量
    data(){
        return{
            msg:"我是zifi组件",
            zifu:"",
        }
    },
    // 2 注册局部组件
     components:{
        //  可以写多个
        // 标签别名：引入子组件时起的名字
        // abc:One
        // 标签：引入组件的时起的名字
        // One:One 等价于下面
        One,
     },
    // 存放函数的地方
    methods:{
        // 5 接收参数。里面有一个参数，接收儿子发送的数据
        handleData(params){
            console.log(params,"我是儿子接收的参数")
            // 将接收的值给data中的变量
            this.zifu=params
        }
    },
    // dom加载完成
    mounted(){

    }
}
/*
    子传父：
        1 在项目中引入子组件
        2 在父组件中挂载注册局部组件，并且在父组件里面使用子组件（在父组件里面使用标签）
        3 当子组件在父组件当中当作标签去使用的时候，给子组件绑定一个自定义方法，值为接收参数的函数， 注意这个函数不允许加(),否则接收不到
        4 在子组件内部通过this.$emit()进行参数传递，有两个参数
            this.$emit('注册绑定的自定义方法名',传递的值)
        
        第3步接收
        第4步传递
*/ 
</script>
<style lang="scss" scoped>
.zifu::v-deep{
    padding: 50px 30px;
    background: blue;
    color: #fff;
    h1{
        color:#fff;
        padding: 10px 0;
    }
}
</style>