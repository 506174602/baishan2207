<template>
    <div class="one">
        <h2>{{msg}}</h2>
        <button @click="handleClick">子传父</button>
    </div>
</template>
<script>
// 导出
export default{
    // 标识
    name:"zOne",
    // 定义变量
    data(){
        return{
            msg:"我是one组件"
        }
    },
    // 存放函数的地方
    methods:{
        handleClick(){
            // 子传父传递
            // 参数1：父组件中自定义的方法名，参数2：要传递参数
            this.$emit('handleYuanye',this.msg)
        }
    },
    // dom加载完成
    mounted(){
        // 默认触发
        this.handleClick()
    }
}
</script>
<style lang="scss" scoped>
.one::v-deep{
    padding: 10px 30px;
    background: green;
}
</style>