<template>
    <div class="one">
        <h2>{{msg}}</h2>
        <p>
            <!-- 父组件里面的msg，只不过绑定的自定义属性时str，所有接收渲染的时候str -->
            我是父组件接收的参数：{{str}}----{{arra}}---{{arr}}
        </p>
    </div>
</template>
<script>
// 导出
export default{
    // 标识
    name:"zOne",
    // 定义变量
    data(){
        return{
            msg:"我是one组件",
            // 我把接收的参数给了arr
            arr:this.arra
        }
    },
    // 5 接收参数，绑定的自定义的属性名
    props:{
        // 绑定的自定义属性
        str:{
            // 接收的数据类型
            type:String, 
            // 如果没有str这个属性，没有绑定自定义参数时，就默认显示我没有东西。默认值
            // default:"我没有东西",
            // 如果时true必需传，与default不能共用
            // require:true        
        },
        // 自定义属性
        arra:{
            type:Array,
            // 必传
            require:true  
        }
    },
    // 存放函数的地方
    methods:{

    },
    // dom加载完成
    mounted(){
        console.log(this)
    }
}
</script>
<style lang="scss" scoped>
.one::v-deep{
    padding: 10px 30px;
    background: green;
}
</style>