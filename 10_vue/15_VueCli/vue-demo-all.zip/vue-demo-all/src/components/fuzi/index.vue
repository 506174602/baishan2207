<template>
  <div class="fuzi">
    <h1>{{ msg }}</h1>
    <!-- 3 使用标签 -->
    <!-- 4 绑定自定义属性 -->
    <!-- :自定义属性="data中定义变量，要传给儿子的变量值" -->
    <One :str="msg" :arra="arr"></One>
    <p>我是非父子传参接收的参数：{{feifuzi}}</p>
    <p>我是vuex接收的值：{{this.$store.state.count}}</p>
  </div>
</template>
<script>
// 1 导入子组件
import One from "@/components/fuzi/zOne.vue";
// 导出
export default {
  // 标识
  name: "zOne",
  // 定义变量
  data() {
    return {
      msg: "我是fuzi组件",
      arr: [1, 2, 3, 4, 5, 6],
      feifuzi:""
    };
  },
  // 2 注册局部组件
  components: {
    //  可以写多个
    // 标签别名：引入子组件时起的名字
    // abc:One
    // 标签：引入组件的时起的名字
    // One:One 等价于下面
    One,
  },
  // 存放函数方法的地方
  methods: {},
  // dom加载完成
  mounted() {
    // 3 非父子接收
    // this.$store里面起的vue原型的名字.$on(自定义的方法名字，(接收的参数)=>{})
    this.$observer.$on('handleLxl',(params)=>{
      console.log(params,"非父子接收")
      this.feifuzi=params
    })
  },
};

/*
    父传子步骤：
        1 在项目中引入子组件
        2 在父组件中挂载注册局部组件，并且在父组件里面使用子组件（在父组件里面使用标签）
        3 当子组件在父组件中当做标签去使用的时候，给子组件绑定一个自定义属性，值是父组件里面定义的变量（需要传给子组件里面的值）
        4 在子组件内部通过propos的方式进行接收
        插值渲染{{你定义的自定义属性名称}}或者在子组件data中定义变量msg，然后将父组件传递过来的参数this.abc赋值给子组件里的msg，插值渲染{{msg}}
*/
</script>

<style lang="scss" scoped>

.fuzi::v-deep {
  padding: 50px 30px;
  background: blue;
  color: #fff;
  h1 {
    color: #fff;
    padding: 10px 0;
  }
}
</style>
