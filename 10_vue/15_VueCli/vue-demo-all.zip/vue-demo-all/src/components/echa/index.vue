<template>
  <div class="echars">
    <div class="h1">
      135455 线上图标库的使用
      <!-- class必需有的类名iconfont 后面跟着图标的类名 -->
      <i class="iconfont iconshexiangtou"></i>
    </div>
    <div id="echar" style="width: 1000px; height: 500px" ref="ech"></div>
  </div>
</template>
<script>
// 导出
export default {
  // 标识
  name: "zOne",
  // 定义变量
  data() {
    return {};
  },
  // 存放函数的地方
  methods: {
    handleEcha() {
      // 基于准备好的dom，初始化echarts实例
      var myChartContainer = document.getElementById("echar");

      var myChartChina = this.$echarts.init(myChartContainer);

      // 随机数
      // function randomData() {
      //   return Math.round(Math.random() * 500);
      // }
      // 绘制图表
      var optionMap = {
        // 数据提示框组件
        tooltip: {
          // item放到数据区域触发
          trigger: "item",
          // 提示数据格式br表示换行，地图 : {a}（系列名称），{b}（区域名称），{c}（合并数值）, {d}（无）
          formatter: "{b}<br/>{a}{c}台",
        },
        //图例组件
        legend: {
          // 图例列表的布局朝向。
          orient: "vertical",
          left: "left",
        },
        visualMap: {
          left: "10%",
          type: "piecewise",
          top: "70%",
          // text: ["高", "低"],
          // color: ["#003097", "#76a2ff"],
          pieces: [
            { min: 1000, label: "", color: "#1533ED" },
            { min: 600, max: 999, label: "", color: "#1B6BED" },
            { min: 300, max: 599, label: "", color: "#209FED" },
            { min: 100, max: 299, label: "", color: "#8881FF" },
            { min: 0, max: 99, label: "", color: "#B78DFF" },
          ],
          // 隐藏
          show: true,
          textStyle: {
            color: "#fff",
          },
        },
        series: [
          {
            name: "",
            type: "map",
            mapType: "china",
            // 图元颜色
            color: "#dce0e5",
            itemStyle: {
              normal: {
                borderColor: "#0e2550",
                borderWidth: 1,
              },
              emphasis: {
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 20,
                borderWidth: 0,
                shadowColor: "#0e2550",
                // 地图高亮
                areaColor: "#ee6951",
              },
            },
            showLegendSymbol: true,
            // 图形上的文本标签，地图默认显示数据名
            label: {
              normal: {
                show: true,
                color: "#dce0e5",
                fontSize: 10,
              },
              emphasis: {
                show: true,
              },
            },
            data: [
              // value:randomData()
              { name: "北京", value: 872 },
              { name: "天津", value: 308 },
              { name: "上海", value: 795 },
              { name: "重庆", value: 416 },
              { name: "河北", value: 795 },
              { name: "河南", value: 586 },
              { name: "云南", value: 113 },
              { name: "辽宁", value: 387 },
              { name: "黑龙江", value: 486 },
              { name: "湖南", value: 189 },
              { name: "安徽", value: 273 },
              { name: "山东", value: 2358 },
              { name: "新疆", value: 342 },
              { name: "江苏", value: 2971 },
              { name: "浙江", value: 1372 },
              { name: "江西", value: 387 },
              { name: "湖北", value: 274 },
              { name: "广西", value: 143 },
              { name: "甘肃", value: 143 },
              { name: "山西", value: 317 },
              { name: "内蒙古", value: 148 },
              { name: "陕西", value: 208 },
              { name: "吉林", value: 266 },
              { name: "福建", value: 346 },
              { name: "贵州", value: 96 },
              { name: "广东", value: 1369 },
              { name: "青海", value: 158 },
              { name: "西藏", value: 0 },
              { name: "四川", value: 325 },
              { name: "宁夏", value: 188 },
              { name: "海南", value: 105 },
              { name: "台湾", value: 0 },
              { name: "香港", value: 0 },
              { name: "澳门", value: 0 },
            ],
          },
        ],
        geo: {
          map: "china", // 地图选择china，对应引入的china.js
        },
      };

      myChartChina.setOption(optionMap);
      // 响应式
      window.onresize = function () {
        myChartChina.resize();
      };
    },
  },
  // dom加载完成
  mounted() {
    this.handleEcha();
  },
};
</script>
<style lang="scss">
.h1 {
  font-family: Digital;
  font-size: 40px;
}
.echars{
  background: black;
}
</style>