<template>
  <div class="echars">
    <div class="h1">
      135455 线上图标库的使用
      <!-- class必需有的类名iconfont 后面跟着图标的类名 -->
      <i class="iconfont iconshexiangtou"></i>
    </div>
    <div id="echar" style="width: 1000px; height: 500px" ref="ech"></div>
  </div>
</template>
<script>
// 导出
export default {
  // 标识
  name: "zOne",
  // 定义变量
  data() {
    return {};
  },
  // 存放函数的地方
  methods: {
    handleEcha() {
      // 基于准备好的dom，初始化echarts实例
      var myChartContainer = document.getElementById("echar");

      var myChartChina = this.$echarts.init(myChartContainer);

      // 随机数
      // function randomData() {
      //   return Math.round(Math.random() * 500);
      // }
      // 绘制图表
      var optionMap = {
        title: {
          text: "中国空气质量",
          left: "center",
        },

        tooltip: {
          alwaysShowContent: true, // 提示框总是显示（不再是鼠标离开就消失）
          enterable: true, // 允许提示框被点击
          formatter: function (params) {
            var value = params.value;
            var a =
              '<br> <a href="http://www.baidu.com" style="color: red">查看详情</a>';
            return params.name + ": " + value[2] + a;
          },
        },

        geo: {
          map: "china", // 地图选择china，对应引入的china.js
          silent: true, // 禁止图形响应鼠标事件
          itemStyle: {
            color: "#004981", // 背景颜色
            borderColor: "rgb(54,192,118)", // 边框颜色
          },
        },
        series: [
          {
            type: "effectScatter", //  指明图表类型：带涟漪效果的散点图
            coordinateSystem: "geo", //  指明绘制在geo坐标系上
            itemStyle: {
              color: function (params) {
                var color = "";
                var value = params.value;
                if (value[2] < 50) {
                  color = "rgb(62, 212, 255)";
                }
                if (value[2] >= 50 && value[2] < 100) {
                  color = "rgb(62, 212, 255)";
                }
                if (value[2] >= 100) {
                  color = "rgb(62, 212, 255)";
                }
                return color;
              },
            },

            // 散点图大小
            symbolSize: function (val) {
              return val[2] / 5;
            },
            data: [
              {
                name: "上海",
                value: [121.47, 31.23, 55],
              },
              {
                name: "北京",
                value: [116.4, 39.9, 110],
              },
              {
                name: "重庆",
                value: [106.55, 29.56, 32],
              },
            ],
          },
        ],
      };

      myChartChina.setOption(optionMap);
      // 响应式
      window.onresize = function () {
        myChartChina.resize();
      };
    },
  },
  // dom加载完成
  mounted() {
    this.handleEcha();
  },
};
</script>
<style lang="scss">
.h1 {
  font-family: Digital;
  font-size: 40px;
}
.echars {
  background: black;
}
</style>