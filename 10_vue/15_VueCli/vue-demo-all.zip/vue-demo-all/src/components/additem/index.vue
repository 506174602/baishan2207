<template>
  <div>
    <el-form
      :model="ruleForm"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="团队名称" prop="name">
        <el-select
          v-model="ruleForm.name"
          clearable
          placeholder="请选择"
          style="width: 100%"
        >
          <!-- 
                label:显示的内容
                value:往后端传递的参数
             -->
          <el-option
            v-for="(item, index) in options"
            :key="index"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="团队邮箱" prop="email">
        <el-input v-model="ruleForm.email"></el-input>
      </el-form-item>
      <el-form-item label="团队描述" prop="miaoshu">
        <el-input type="textarea" v-model="ruleForm.miaoshu"></el-input>
      </el-form-item>
      <el-form-item>
        <!-- 判断id有没有值。如果没有id就显示加载立即创建 -->
        <el-button
          type="primary"
          @click="submitForm('ruleForm')"
          v-if="!this.$route.query.id"
          >立即创建</el-button
        >
        <!-- 否则就是有id就显示确定修改 -->
        <el-button type="primary" @click="handleEidt('ruleForm')" v-else
          >确定修改</el-button
        >
        <el-button @click="resetForm('ruleForm')">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      ruleForm: {
        name: "",
        email: "",
        miaoshu: "",
      },
      //   后端请求过来的
      options: [
        {
          label: "阚瑞泽战队",
          value: "1001",
        },
        {
          label: "袁晔战队",
          value: "1002",
        },
        {
          label: "肖洋战队",
          value: "1003",
        },
      ],
      rules: {
        name: [{ required: true, message: "请选择团队", trigger: "change" }],
        email: [
          // 不必填，我可以允许你不填，但是你不能给我乱填
          { required: false, message: "请输入邮箱", trigger: "change" },
          {
            //  pattern：写正则表达式
            pattern: /\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/,
            message: "请输入正确的邮箱",
            trigger: "blur",
          },
        ],
        miaoshu: [
          { required: true, message: "请输入团队描述", trigger: "change" },
        ],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          let data = {
            teamname: this.ruleForm.name,
            mailbox: this.ruleForm.email,
            teamdescribe: this.ruleForm.miaoshu,
          };
          this.axios
            .post("test/inertTeam2", this.$qs.stringify(data), {
              headers: {
                "Content-type": "application/x-www-form-urlencoded",
              },
            })
            .then((res) => {
              console.log(res);
              if (res.data == 200) {
                this.$message({
                  message: "创建成功",
                  type: "success",
                });
                // 清空内容
                this.$refs[formName].resetFields();

                // 路由跳转
                this.$router.push({
                  path: "/index/list",
                });
              }
            });
        } else {
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // 编辑反显：把接收的值赋值给input框
    handleQuery() {
      this.ruleForm.name = this.$route.query.teamname;
      this.ruleForm.email = this.$route.query.mailbox;
      this.ruleForm.miaoshu = this.$route.query.teamdescribe;
      console.log(this.$route.query);
    },
    // 确定编辑
    handleEidt(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$axios
            .post(
              "test/updateTeam",
              this.$qs.stringify({
                id: this.$route.query.id,
                // 绑定的是input里面的值
                teamname: this.ruleForm.name,
                mailbox: this.ruleForm.email,
                teamdescribe: this.ruleForm.miaoshu,
              })
            )
            .then((res) => {
              console.log(res);
              if (res.data.code == 200) {
                this.$message({
                  message: res.data.message,
                  type: "success",
                });
                // 修改成功跳转到团队看板
                this.$router.push({
                  path: "/index/list",
                });
              }
            });
        } else {
          return false;
        }
      });
    },
  },
  created() {
    // 页面打开显示
    this.handleQuery();
  },
  mounted() {},
};
</script>
<style lang="scss" scoped>
</style>