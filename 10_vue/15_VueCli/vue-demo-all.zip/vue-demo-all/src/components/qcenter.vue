<template>
  <el-container id="box-main">
    <!-- 左侧导航 -->
    <el-aside width="260px" style="background-color: rgba(238, 241, 246, 1)">
      <!-- 
          unique-opened 默认只展开一个菜单
          router	是否使用 vue-router 的模式，启用该模式会在激活导航时以 index 作为 path 进行路由跳转(开启路由模式)
          default-active 当前激活菜单的 index,判断绑定是不是首页,如果是就绑定这个路径,如果不是就是你当前点击的路径并添加类名is-active
       -->
      <el-menu
        class="el-menu-vertical-demo"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b"
        unique-opened
        router
        :default-active="$route.path=='index/zifu'?'index/fuzi':$route.path"
      >
        <el-submenu index="1">
          <template slot="title">
            <i class="el-icon-location"></i>
            <span>组件传参</span>
          </template>
          <!-- 
              index是跳转的路径名。router里面配置的path
              this.$router.push({
                path:"跳转路径"
              })
           -->
          <el-menu-item-group>
            <el-menu-item index="/index/fuzi">父子传参</el-menu-item>
            <el-menu-item index="/index/zifu">子父传参</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-submenu index="6">
          <template slot="title">
            <!-- 图标 -->
            <i class="el-icon-s-promotion"></i>
            <span>路由传参</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/index/params">params传参</el-menu-item>
            <el-menu-item index="/index/query">query传参</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
        <el-menu-item index="/index/echa">
          <i class="el-icon-menu"></i>
          <span slot="title">echars</span>
        </el-menu-item>
        <!-- disabled禁用 -->
        <el-menu-item index="/index/axios">
          <i class="el-icon-document"></i>
          <span slot="title">axios</span>
        </el-menu-item>
        <el-menu-item index="/index/vuex">
          <i class="el-icon-setting"></i>
          <span slot="title">vuex</span>
        </el-menu-item>
        <el-submenu index="5">
          <template slot="title">
            <i class="el-icon-location"></i>
            <span>海南残联</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="/index/add">创建团队</el-menu-item>
            <el-menu-item index="/index/list">团队看板</el-menu-item>
          </el-menu-item-group>
          <el-menu-item-group>
            <el-menu-item index="/index/kb">活动看板</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </el-aside>
    <!-- 右边导航 -->
    <el-main>
        <!-- 动态显示组件区域 -->
        <!-- 
            当path的路径与用户请求的路径一致的情况下用router-view来动态渲染component对应的组件
         -->
        <router-view></router-view>
    </el-main>
  </el-container>
</template>
<script>
export default{
  data(){
    return{
      msg:"vue"
    }
  },
  methods:{
  },
  mounted(){
    // console.log(this.$route.path,"我是路径")
  },
}
</script>

<style lang="scss" scoped>
#box-main::v-deep{
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  top:60px;
  .el-menu{
    height: 100%;
  }
  // .is-active{
  //   background: blue !important;
  // }
  // 修改图标颜色
  // .el-submenu__title,.el-menu-item{
  //   >i:nth-child(1){
  //     color:yellow
  //   }
  // }
  .el-main{
    margin-top: 30px;
  }
}
</style>