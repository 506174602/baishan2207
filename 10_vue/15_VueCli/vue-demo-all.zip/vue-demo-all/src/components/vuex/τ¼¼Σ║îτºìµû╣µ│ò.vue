<template>
  <div>
    <h3>vuex状态存储</h3>
    <!-- 
            1、状态存储
            2、可以实现非父子组件之间的传参
            实现原理：
            在组件中将参数传到store文件夹下的index.js中的state中存储起来，然后进行action(异步处理)，mutaction(同步处理)，getters(计算属性)
            等一系列操作后，在其他组件中进行接收。
            因为vuex在main.js中引入的，所以是全局的，所有的组件都能用
         -->
    <el-button type="primary" @click="handleAsync"
      >我要充钱（异步方法）</el-button
    >
    <el-button type="success" @click="handleSync"
      >我要充钱（同步方法）</el-button
    >

    <!-- 第二种方法显示：计算属性storeCount -->
    <div v-if="storeCount<200">
        当前状态值：{{storeCount}}<br>
        游客身份
    </div>
    <div v-else-if="storeCount>200&&storeCount<400">
        当前状态值：{{storeCount}}<br>
        黑铁会员
    </div>
    <div v-else-if="storeCount>400&&storeCount<998">
        当前状态值：{{storeCount}}<br>
        青铜会员
    </div>
    <div v-else-if="storeCount>1000">
        当前状态值：{{storeCount}}<br>
        白银会员
    </div>
  </div>
</template>
<script>
export default {
  // 定义变量
  data() {
    return {
      five: 5,
      money: 50,
    };
  },
  // 函数
  methods: {
    handleAsync() {
      console.log(this);
      // 异步方法
      // dispatch是触发action里面的方法，参数1：action里面的函数名，参数2：需要传递的参数
      this.$store.dispatch("handleChange",this.five);
    },
    handleSync() {
      // 同步方法 直接触发mutation中的handleMutation中的方法
      // commit("mutation中的handleMutation中的方法",要传递的值)
      this.$store.commit("handleMutation",this.money)
    },
  },
  // 计算属性,存放计算的函数，里面有返回值，将返回值给这个函数。这个函数就是返回值就是结果
  computed:{
    storeCount(){
      return this.$store.state.count
    }
  },
  // 生命周期
  mounted() {},
};
</script>
