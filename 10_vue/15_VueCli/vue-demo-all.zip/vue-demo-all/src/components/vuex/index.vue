<template>
  <div>
    <h3>vuex状态存储</h3>
    <!-- 
            1、状态存储
            2、可以实现非父子组件之间的传参
            实现原理：
            在组件中将参数传到store文件夹下的index.js中的state中存储起来，然后进行action(异步处理)，mutaction(同步处理)，getters(计算属性)
            等一系列操作后，在其他组件中进行接收。
            因为vuex在main.js中引入的，所以是全局的，所有的组件都能用
         -->
    <el-button type="primary" @click="fn(five)"
      >mapActions（异步方法）</el-button
    >
    <el-button type="success" @click="fn1(money)"
      >mapMutations（同步方法）</el-button
    >
    <!-- 第三种方法显示：getters -->
    <div v-if="count < 200">
      当前状态值：{{ count }}<br />
      游客身份
    </div>
    <div v-else-if="count > 200 && count < 400">
      当前状态值：{{ count }}<br />
      黑铁会员
    </div>
    <div v-else-if="count > 400 && count < 998">
      当前状态值：{{ count }}<br />
      青铜会员
    </div>
    <div v-else-if="count > 1000">
      当前状态值：{{ count }}<br />
      白银会员
    </div>
  </div>
</template>
<script>
// 内置辅助函数 渲染数据:mapState；异步函数:mapActions；同步修改函数:mapMutations；计算属性:mapGetters
import { mapState ,mapActions, mapMutations } from "vuex";
export default {
  // 定义变量
  data() {
    return {
      five: 5,
      money: 50,
    };
  },
  // 函数
  methods: {
    // 辅助函数相当于this.$store.dispatch(action里面的方法，传递的值)
    // 触发action中的handleChange方法，异步方法
    ...mapActions({
      // 当前组件触发的那个fn(msg)函数：handleChange是action中的handleChange方法
      fn: "handleChange",
    }),

    // 辅助函数相当于this.$store. commit("mutation中的handleMutation中的方法",要传递的值)
    // 触发mutations中的handleMutation方法，同步方法
    ...mapMutations({
      // 当前组件触发的那个fn1(msg)函数：handleMutation是mutations中的handleMutation方法
      fn1: "handleMutation",
    }),
  },
  // 计算属性,存放计算的函数，里面有返回值，将返回值给这个函数。这个函数就是返回值就是结果
  computed: {
    // count是getters中的count，{{count}}
    ...mapState(["count"])

    // 起别名   {{yuanye}}
    // ...mapState({
    //   yuanye:"count"
    // })
  },
  // 生命周期
  mounted() {},
};
</script>
