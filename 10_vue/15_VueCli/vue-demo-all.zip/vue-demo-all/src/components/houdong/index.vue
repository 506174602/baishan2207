<template>
  <div>
    <el-table
      :data="tableData"
      :stripe="true"
      border
      height="500px"
      style="width: 100%"
    >
      <!-- prop对应的是后端的字段 -->
      <el-table-column type="index" label="序号" width="50"> </el-table-column>
      <el-table-column prop="fundtitle" label="标题"> </el-table-column>
      <el-table-column prop="status" label="状态">
        <!-- template插槽, slot-scope="scope" 返回整个表格的属性，scope.row当前行的数据-->
        <template slot-scope="scope">
          <el-tag
            v-if="scope.row.status == 1"
            type="success"
            @click="handleA(scope.row)"
            >已报名</el-tag
          >
          <el-tag v-else-if="scope.row.status == 2" type="warning"
            >未报名</el-tag
          >
          <el-tag type="danger" v-else>已结束</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="fundtype" label="类型"> </el-table-column>
      <el-table-column prop="fundtarget" label="目标"> </el-table-column>
      <el-table-column prop="fundpeople" label="人数"> </el-table-column>
    </el-table>
    <div>
      <!-- 3 使用组件 -->
      <!-- 
             4 父子传参，给子组件绑定自定义属性。
             
             子父传参：给子组件绑定自定义方法，方法触发一个函数，这个函数不能与（）,并且接收了一个参数
             这个参数就是子组件传递过来的值。
          -->
      <Pagination
       :totals="total"
       :pageSizes="pageSize"
       @handlePage="handleRow"
       >
       </Pagination>
    </div>
  </div>
</template>
<script>
// 1 引入组件
import Pagination from "./pagination.vue";
export default {
  data() {
    return {
      tableData: [],
      //   页码
      page: 1,
      //   总条数
      total: null,
      //   每页显示的条数
      pageSize: 10,
    };
  },
  components: {
    // 2 注册组件
    Pagination,
  },
  methods: {
    // 调用接收的参数
    handleSeach(index) {
      //   this.$qs.stringify()将对象转成字符串形式
      // get默认就是字符串
      this.axios
        .get("test/getfundAll", {
          params: {
            // 默认请求第一页数据
            pageNum: index,
            // 请求每页显示几条数据
            // size:10
          },
        })
        .then((res) => {
          //   将请求的数据列表给表格
          this.tableData = res.data.list;
          //   将接口请求的总条数赋值给data中的total
          this.total = res.data.total;
        });
    },
    handleA(row) {
      console.log(row);
    },
    // 子父传参接收
    handleRow(index){
        console.log(index,"我是子组件接收的参数")
        // 重新渲染数据
        this.handleSeach(index);
    }
  },
  mounted() {
    //   把data中定义的page传进去
    this.handleSeach(this.page);
  },
};
</script>
