<template>
  <div>
    <el-table
      :data="tableData"
      :stripe="true"
      border
      height="500px"
      style="width: 100%"
    >
      <!-- prop对应的是后端的字段 -->
      <el-table-column type="index" label="序号" width="50"> </el-table-column>
      <el-table-column prop="fundtitle" label="标题"> </el-table-column>
      <el-table-column prop="status" label="状态">
        <!-- template插槽, slot-scope="scope" 返回整个表格的属性，scope.row当前行的数据-->
        <template slot-scope="scope">
          <el-tag
            v-if="scope.row.status == 1"
            type="success"
            @click="handleA(scope.row)"
            >已报名</el-tag
          >
          <el-tag v-else-if="scope.row.status == 2" type="warning"
            >未报名</el-tag
          >
          <el-tag type="danger" v-else>已结束</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="fundtype" label="类型"> </el-table-column>
      <el-table-column prop="fundtarget" label="目标"> </el-table-column>
      <el-table-column prop="fundpeople" label="人数"> </el-table-column>
    </el-table>
    <div>
      <!-- 
            total：总条数
            prev：显示上一页
            next：显示下一页
            jumper：显示跳转到那一页
            pager：显示的页数

            current-change：当页数发生变化的时候触发，并且这个函数接收了一个参数，当前的页数
            page-size：每页显示的条数
            current-page：当前选中页数
         -->
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="1"
        :page-size="10"
        layout="total, prev, pager, next, jumper"
        :total="total"
      >
      </el-pagination>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [],
      //   页码
      page: 1,
      //   总条数
      total: null,
    };
  },
  methods: {
    // 调用接收的参数
    handleSeach(index) {
      //   this.$qs.stringify()将对象转成字符串形式
      // get默认就是字符串
      this.axios
        .get("test/getfundAll", {
          params: {
            // 默认请求第一页数据
            pageNum: index,
            // 请求每页显示几条数据
            // size:10
          },
        })
        .then((res) => {
          //   将请求的数据列表给表格
          this.tableData = res.data.list;
          //   将接口请求的总条数赋值给data中的total
          this.total = res.data.total;
        });
    },
    handleA(row) {
      console.log(row);
    },
    // 分页
    handleCurrentChange(val) {
      console.log(val, "当前页");
      // 当页数发生变化的时候触发接收的val传给这个接口函数
      this.handleSeach(val);
    },
  },
  mounted() {
    //   把data中定义的page传进去
    this.handleSeach(this.page);
  },
};
</script>
