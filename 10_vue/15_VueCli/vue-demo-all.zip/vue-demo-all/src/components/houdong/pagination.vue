<template>
  <div>
    <!-- 
            total：总条数
            prev：显示上一页
            next：显示下一页
            jumper：显示跳转到那一页
            pager：显示的页数

            current-change：当页数发生变化的时候触发，并且这个函数接收了一个参数，当前的页数
            page-size：每页显示的条数
            current-page：当前选中页数
         -->
    <el-pagination
      @current-change="handleCurrentChange"
      :current-page="1"
      :page-size="pageSizes"
      layout="total, prev, pager, next, jumper"
      :total="totals"
    >
    </el-pagination>
  </div>
</template>
<script>
export default {
  // 5 在子组件中props接收,自定义属性
  props: {
    totals: {
      type: Number,
    },
    pageSizes: {
      type: Number,
    },
  },
  data() {
    return {};
  },
  methods: {
    // 分页
    // 子父传参，当页面发生变化的时候，就发送数据给父亲
    handleCurrentChange(val) {
      //   console.log(val, "当前页");
      //   this.$emit("绑定的自定义方法名")
      this.$emit("handlePage", val);
    },
  },
  mounted() {},
};
</script>
