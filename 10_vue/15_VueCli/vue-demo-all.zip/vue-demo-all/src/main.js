// vue
import Vue from 'vue'
// 引入我们写好的vue文件。App.vue入口文件，最大的组件
import App from './App.vue'
// 引入的路由
import router from './router'
// vuex
import store from './store'

// 1 引入ElementUI并使用
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

// 引入线上图标库或者放在App.vue
// import './assets/icon/iconfont.css';

// 使用
Vue.use(ElementUI);

// 2 引入axios并使用
import axios from "axios";
import VueAxios from "vue-axios";
Vue.use(VueAxios, axios);
// 通过原型使用axios
// 我把axios给了vue的原型
Vue.prototype.$axios = axios;

// 3 引入qs并使用  npm install qs -s
// qs是增加了一些安全性的查询字符串解析和序列化字符串的库

// this.$qs.stringify() 将对象序列化为URL的形式，以&拼接。
// this.$qs.parse() 将url解析成对象的形式
import qs from "qs";
Vue.prototype.$qs = qs;

// 4 引入echarts并使用
import * as echarts from "echarts";
Vue.prototype.$echarts = echarts;
// 还要特别引入china.json，这样中国地图才会出现，不然只会出现右下角的南海诸岛
import china from './assets/china.json'
echarts.registerMap('china', china)


// productionTip设置为false 可以阻止vue在启动的时候生成生产提示
// 开发环境下（也就是在本地电脑运行），vue会提供很多警告来帮你对付常见的错误与陷阱
// 而在生产环境下（发布到服务器上），这些经过语句却没有用，反而会增加应用的体积
Vue.config.productionTip = false

// 配置请求的路径，把这个接口地址存在axios.defaults.baseURL，使用的时候不用拼接路径this.axios("test/login")
// 开发环境
axios.defaults.baseURL="http://121.196.8.145:10000/" 
// 生产环境
// axios.defaults.baseURL="http://www.iimake.com/" 

// 创建vue实例，实例化
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
/*
  main.js是项目的入口文件，项目中所有的页面都会加载main.js。所有main.js有三个作用：
  1、实例化vue
  2、放置项目中经常会用到的插件或者css样式。比如网络请求插件axios和elmentUi、vue-resource
  在main.js挂载的都是全局变量，所有的组件都能用
  3、存储全局变量
*/ 
